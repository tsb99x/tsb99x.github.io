#!/bin/bash -eux

git archive --format=tar.gz --prefix=solutions-"$(git describe --tags)/" \
        -o /tmp/solutions.tar.gz main
