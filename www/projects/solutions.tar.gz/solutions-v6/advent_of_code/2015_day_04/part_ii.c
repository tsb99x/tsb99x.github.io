#include <limits.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ARG_LEN 32U
#define BUF_SIZE 64

static long find_six_zeroes(const char prefix[])
{
        char buf[BUF_SIZE] = {0};
        unsigned char md[EVP_MAX_MD_SIZE] = {0};
        unsigned int md_size = 0;

        for (long i = 1; i < LONG_MAX; i++) {
                int chs = snprintf(buf, sizeof(buf), "%s%ld", prefix, i);
                if (chs < 0) {
                        perror("Failed to snprintf");
                        exit(EXIT_FAILURE);
                }
                if ((size_t)chs >= sizeof(buf)) {
                        (void)fputs("Failed to snprintf: Buffer overflow\n",
                                    stderr);
                        exit(EXIT_FAILURE);
                }

                if (!EVP_Digest(buf, strlen(buf), md, &md_size, EVP_md5(),
                                NULL)) {
                        ERR_print_errors_fp(stderr);
                        exit(EXIT_FAILURE);
                }

                if ((md[0] == 0x00U) && (md[1] == 0x00U) && (md[2] == 0x00U)) {
                        return i;
                }
        }

        return -1;
}

int main(int argc, char *argv[])
{
        size_t arg_len = 0;
        long suffix = 0;

        if (argc != 2) {
                (void)fprintf(stderr,
                              "Only one argument is accepted!\n"
                              "Use like this: %s prefix\n",
                              argv[0]);
                return EXIT_FAILURE;
        }

        arg_len = strlen(argv[1]);
        if (arg_len > MAX_ARG_LEN) {
                (void)fprintf(stderr,
                              "Secret prefix argument must be less than %u "
                              "chars of length, but was %zu\n",
                              MAX_ARG_LEN, arg_len);
                return EXIT_FAILURE;
        }

        suffix = find_six_zeroes(argv[1]);
        if (suffix < 0) {
                (void)fprintf(stderr,
                              "Failed to find MD5 with 6 zeroes for %s\n",
                              argv[1]);
                return EXIT_FAILURE;
        }
        (void)printf("%ld\n", suffix);

        return EXIT_SUCCESS;
}
